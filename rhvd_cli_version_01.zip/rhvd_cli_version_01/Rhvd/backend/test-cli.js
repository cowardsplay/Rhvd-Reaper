#!/usr/bin/env node

// Simple test version without external dependencies
console.log('RHVD CLI Tool - Test Version');
console.log('============================');

// Simulate command line arguments
const args = process.argv.slice(2);

if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
  console.log(`
Usage: node test-cli.js <command> [options]

Commands:
  hold-user [userSid]     Put an Active Directory user on forensic hold
  archive-vm [vmId]       Archive a virtual machine by VM ID
  release-hold [userSid]  Release a user from forensic hold
  list-held-users         List all currently held users
  interactive             Run in interactive mode with menu options

Options:
  -u, --username <username>  Horizon API Username
  -p, --password <password>  Horizon API Password

Examples:
  node test-cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234
  node test-cli.js archive-vm vm-12345
  node test-cli.js interactive

Note: This is a test version. Install dependencies and use cli.js for full functionality.
  `);
} else {
  const command = args[0];
  
  switch (command) {
    case 'hold-user':
      const userSid = args[1] || 'PROMPT_FOR_SID';
      console.log(`Would put user ${userSid} on forensic hold`);
      break;
      
    case 'archive-vm':
      const vmId = args[1] || 'PROMPT_FOR_VM_ID';
      console.log(`Would archive VM ${vmId}`);
      break;
      
    case 'release-hold':
      const releaseSid = args[1] || 'PROMPT_FOR_SID';
      console.log(`Would release user ${releaseSid} from forensic hold`);
      break;
      
    case 'list-held-users':
      console.log('Would list all currently held users');
      break;
      
    case 'interactive':
      console.log('Would start interactive mode with menu options');
      break;
      
    default:
      console.log(`Unknown command: ${command}`);
      console.log('Run with --help for usage information');
  }
} 