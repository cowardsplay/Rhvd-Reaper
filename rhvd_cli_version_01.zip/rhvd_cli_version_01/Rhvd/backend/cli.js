#!/usr/bin/env node

const { Command } = require('commander');
const chalk = require('chalk');
const inquirer = require('inquirer');
const axios = require('axios');
require('dotenv').config();

const program = new Command();

// Function to display comprehensive help information
function displayComprehensiveHelp() {
  console.log(chalk.cyan.bold('\n🚀 RHVD - Horizon Forensics CLI Tool'));
  console.log(chalk.gray('A command-line interface tool for VMware Horizon forensics operations\n'));

  console.log(chalk.yellow.bold('📋 Available Commands:'));
  console.log(chalk.white('  hold-user [userSid]     Put an Active Directory user on forensic hold'));
  console.log(chalk.white('  archive-vm [vmId]       Archive a virtual machine by VM ID'));
  console.log(chalk.white('  release-hold [userSid]  Release a user from forensic hold'));
  console.log(chalk.white('  list-held-users         List all currently held users'));
  console.log(chalk.white('  interactive             Run in interactive mode with menu options'));
  console.log(chalk.white('  help                    Show this comprehensive help information\n'));

  console.log(chalk.yellow.bold('🔧 Command Options:'));
  console.log(chalk.white('  -u, --username <username>  Horizon API Username'));
  console.log(chalk.white('  -p, --password <password>  Horizon API Password'));
  console.log(chalk.white('  -b, --base-url <url>       Horizon API Base URL'));
  console.log(chalk.white('  -h, --help                 Show command-specific help\n'));

  console.log(chalk.yellow.bold('🌐 Horizon API Base URL Configuration:'));
  console.log(chalk.gray('The Horizon API Base URL may require a specific port depending on your VMware Horizon server configuration.\n'));

  console.log(chalk.cyan.bold('Default HTTPS (Port 443):'));
  console.log(chalk.white('  If your Horizon server uses the default HTTPS port, you typically don\'t need to specify the port:'));
  console.log(chalk.gray('  https://horizon.company.com\n'));

  console.log(chalk.cyan.bold('Custom HTTPS Port:'));
  console.log(chalk.white('  If your Horizon server uses a custom HTTPS port, you must specify it:'));
  console.log(chalk.gray('  https://horizon.company.com:8443'));
  console.log(chalk.gray('  https://horizon.company.com:9443\n'));

  console.log(chalk.cyan.bold('Common VMware Horizon Ports:'));
  console.log(chalk.white('  | Service                    | Default Port | Protocol |'));
  console.log(chalk.white('  |----------------------------|--------------|----------|'));
  console.log(chalk.white('  | Horizon Connection Server | 443          | HTTPS    |'));
  console.log(chalk.white('  | Horizon Connection Server | 8443, 9443   | HTTPS    |'));
  console.log(chalk.white('  | Horizon UAG               | 443          | HTTPS    |'));
  console.log(chalk.white('  | Horizon UAG (custom)      | 8443, 9443   | HTTPS    |'));
  console.log('');

  console.log(chalk.yellow.bold('💡 Port Usage Tips:'));
  console.log(chalk.white('  1. Start without a port (e.g., https://horizon.company.com)'));
  console.log(chalk.white('  2. If you get connection errors, try adding common ports like :8443 or :9443'));
  console.log(chalk.white('  3. Check with your VMware administrator for the correct port configuration'));
  console.log(chalk.white('  4. Use HTTPS whenever possible for security\n'));

  console.log(chalk.yellow.bold('📝 Usage Examples:'));
  console.log(chalk.cyan.bold('Interactive Mode (Recommended for beginners):'));
  console.log(chalk.gray('  node cli.js interactive\n'));

  console.log(chalk.cyan.bold('Command Line Mode:'));
  console.log(chalk.gray('  # Interactive prompts for base URL, user SID, and credentials'));
  console.log(chalk.white('  node cli.js hold-user\n'));

  console.log(chalk.gray('  # With user SID provided (default port 443)'));
  console.log(chalk.white('  node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234\n'));

  console.log(chalk.gray('  # With custom port and credentials'));
  console.log(chalk.white('  node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234 -b https://horizon-server.com:8443 -u username -p password\n'));

  console.log(chalk.cyan.bold('Environment Variables:'));
  console.log(chalk.gray('  Create a .env file in the backend directory (optional):'));
  console.log(chalk.white('  HORIZON_API_BASE=https://your-horizon-server.com\n'));

  console.log(chalk.yellow.bold('🔒 Security Notes:'));
  console.log(chalk.white('  • Credentials are only stored in memory during the session'));
  console.log(chalk.white('  • Passwords are hidden when entered interactively'));
  console.log(chalk.white('  • Base URL is validated for proper format'));
  console.log(chalk.white('  • Consider using environment variables for credentials in production'));
  console.log(chalk.white('  • The .env file should not be committed to version control\n'));

  console.log(chalk.yellow.bold('❌ Error Handling:'));
  console.log(chalk.white('  The CLI provides clear error messages for:'));
  console.log(chalk.white('  • Missing credentials'));
  console.log(chalk.white('  • Invalid API responses'));
  console.log(chalk.white('  • Network connectivity issues'));
  console.log(chalk.white('  • Invalid user SIDs or VM IDs'));
  console.log(chalk.white('  • Invalid base URL format\n'));

  console.log(chalk.yellow.bold('📚 Getting Help:'));
  console.log(chalk.white('  node cli.js --help                    # Show general help'));
  console.log(chalk.white('  node cli.js help                      # Show this comprehensive help'));
  console.log(chalk.white('  node cli.js interactive               # Interactive mode with help option'));
  console.log(chalk.white('  node cli.js hold-user --help          # Show command-specific help'));
  console.log(chalk.white('  node cli.js archive-vm --help         # Show command-specific help'));
  console.log(chalk.white('  node cli.js release-hold --help       # Show command-specific help'));
  console.log(chalk.white('  node cli.js list-held-users --help    # Show command-specific help'));
  console.log(chalk.white('  node cli.js interactive --help        # Show command-specific help\n'));

  console.log(chalk.gray('For more information, visit the project documentation or contact your VMware administrator.'));
}

// Function to display port guidance
function displayPortGuidance() {
  console.log(chalk.cyan('\n📋 Horizon API Base URL Guidelines:'));
  console.log(chalk.gray('• Default HTTPS (port 443): https://horizon-server.com'));
  console.log(chalk.gray('• Custom HTTPS port: https://horizon-server.com:8443'));
  console.log(chalk.gray('• HTTP (not recommended): http://horizon-server.com:8080'));
  console.log(chalk.gray('• Common VMware Horizon ports: 443, 8443, 9443'));
  console.log(chalk.yellow('💡 Tip: Start without a port, add :8443 or :9443 if connection fails\n'));
}

// Function to get base URL for horizon api
async function getBaseUrl() {
  let baseUrl = process.env.HORIZON_API_BASE;
  
  if (!baseUrl) {
    displayPortGuidance();
    const answer = await inquirer.prompt([
      {
        type: 'input',
        name: 'baseUrl',
        message: 'Enter Horizon API Base URL (e.g., https://horizon-server.com or https://horizon-server.com:8443):',
        validate: input => {
          if (!input.trim()) return 'Base URL is required';
          try {
            const url = new URL(input.trim());
            // Check if it's a valid protocol
            if (url.protocol !== 'https:' && url.protocol !== 'http:') {
              return 'Please enter a valid URL with http:// or https:// protocol';
            }
            return true;
          } catch {
            return 'Please enter a valid URL (e.g., https://horizon-server.com or https://horizon-server.com:8443)';
          }
        }
      }
    ]);
    baseUrl = answer.baseUrl.trim();
  }
  
  return baseUrl;
}

// Function to generate auth header dynamically
function createAuthHeader(apiUser, apiPass) {
  return {
    headers: {
      Authorization: `Basic ${Buffer.from(`${apiUser}:${apiPass}`).toString('base64')}`,
      'Content-Type': 'application/json',
      Accept: 'application/json'
    }
  };
}

// Function to prompt for credentials if not provided
async function getCredentials(apiUser, apiPass) {
  if (!apiUser || !apiPass) {
    const answers = await inquirer.prompt([
      {
        type: 'input',
        name: 'apiUser',
        message: 'Enter Horizon API Username:',
        validate: input => input.trim() ? true : 'Username is required'
      },
      {
        type: 'password',
        name: 'apiPass',
        message: 'Enter Horizon API Password:',
        validate: input => input.trim() ? true : 'Password is required'
      }
    ]);
    return answers;
  }
  return { apiUser, apiPass };
}

// Function to display results in a formatted way
function displayResult(data, operation) {
  console.log(chalk.green(`\n✅ ${operation} completed successfully!`));
  console.log(chalk.cyan('Response:'));
  console.log(JSON.stringify(data, null, 2));
}

// Function to display errors
function displayError(error, operation) {
  console.log(chalk.red(`\n❌ ${operation} failed!`));
  if (error.response) {
    console.log(chalk.red(`Status: ${error.response.status}`));
    console.log(chalk.red(`Error: ${error.response.data?.error || error.message}`));
  } else {
    console.log(chalk.red(`Error: ${error.message}`));
  }
}

// CLI Commands
program
  .name('rhvd')
  .description('Horizon Forensics CLI Tool')
  .version('1.0.0');

// Hold User Command
program
  .command('hold-user')
  .description('Put an Active Directory user on forensic hold')
  .argument('[userSid]', 'User Security Identifier (SID)')
  .option('-u, --username <username>', 'Horizon API Username')
  .option('-p, --password <password>', 'Horizon API Password')
  .option('-b, --base-url <url>', 'Horizon API Base URL')
  .action(async (userSid, options) => {
    try {
      // Get base URL
      const baseUrl = options.baseUrl || await getBaseUrl();
      
      // Get user SID if not provided
      if (!userSid) {
        const answer = await inquirer.prompt([
          {
            type: 'input',
            name: 'userSid',
            message: 'Enter User Security Identifier (SID):',
            validate: input => input.trim() ? true : 'User SID is required'
          }
        ]);
        userSid = answer.userSid;
      }

      // Get credentials
      const credentials = await getCredentials(options.username, options.password);

      console.log(chalk.yellow(`\n🔄 Putting user ${userSid} on forensic hold...`));

      const auth = createAuthHeader(credentials.apiUser, credentials.apiPass);
      const response = await axios.post(`${baseUrl}/external/v1/ad-users-or-groups/action/hold`, {
        securityIdentifiers: [userSid]
      }, auth);

      displayResult(response.data, 'User Hold');
    } catch (error) {
      displayError(error, 'User Hold');
      process.exit(1);
    }
  });

// Archive VM Command
program
  .command('archive-vm')
  .description('Archive a virtual machine by VM ID')
  .argument('[vmId]', 'Virtual Machine ID')
  .option('-u, --username <username>', 'Horizon API Username')
  .option('-p, --password <password>', 'Horizon API Password')
  .option('-b, --base-url <url>', 'Horizon API Base URL')
  .action(async (vmId, options) => {
    try {
      // Get base URL
      const baseUrl = options.baseUrl || await getBaseUrl();
      
      // Get VM ID if not provided
      if (!vmId) {
        const answer = await inquirer.prompt([
          {
            type: 'input',
            name: 'vmId',
            message: 'Enter VM ID:',
            validate: input => input.trim() ? true : 'VM ID is required'
          }
        ]);
        vmId = answer.vmId;
      }

      // Get credentials
      const credentials = await getCredentials(options.username, options.password);

      console.log(chalk.yellow(`\n🔄 Archiving VM ${vmId}...`));

      const auth = createAuthHeader(credentials.apiUser, credentials.apiPass);
      const response = await axios.post(`${baseUrl}/inventory/v1/machines/action/archive`, {
        ids: [vmId]
      }, auth);

      displayResult(response.data, 'VM Archive');
    } catch (error) {
      displayError(error, 'VM Archive');
      process.exit(1);
    }
  });

// Release Hold Command
program
  .command('release-hold')
  .description('Release a user from forensic hold')
  .argument('[userSid]', 'User Security Identifier (SID)')
  .option('-u, --username <username>', 'Horizon API Username')
  .option('-p, --password <password>', 'Horizon API Password')
  .option('-b, --base-url <url>', 'Horizon API Base URL')
  .action(async (userSid, options) => {
    try {
      // Get base URL
      const baseUrl = options.baseUrl || await getBaseUrl();
      
      // Get user SID if not provided
      if (!userSid) {
        const answer = await inquirer.prompt([
          {
            type: 'input',
            name: 'userSid',
            message: 'Enter User Security Identifier (SID):',
            validate: input => input.trim() ? true : 'User SID is required'
          }
        ]);
        userSid = answer.userSid;
      }

      // Get credentials
      const credentials = await getCredentials(options.username, options.password);

      console.log(chalk.yellow(`\n🔄 Releasing user ${userSid} from forensic hold...`));

      const auth = createAuthHeader(credentials.apiUser, credentials.apiPass);
      const response = await axios.post(`${baseUrl}/external/v1/ad-users-or-groups/action/release-hold`, {
        securityIdentifiers: [userSid]
      }, auth);

      displayResult(response.data, 'User Release');
    } catch (error) {
      displayError(error, 'User Release');
      process.exit(1);
    }
  });

// List Held Users Command
program
  .command('list-held-users')
  .description('List all currently held users')
  .option('-u, --username <username>', 'Horizon API Username')
  .option('-p, --password <password>', 'Horizon API Password')
  .option('-b, --base-url <url>', 'Horizon API Base URL')
  .action(async (options) => {
    try {
      // Get base URL
      const baseUrl = options.baseUrl || await getBaseUrl();
      
      // Get credentials
      const credentials = await getCredentials(options.username, options.password);

      console.log(chalk.yellow('\n🔄 Fetching list of held users...'));

      const auth = createAuthHeader(credentials.apiUser, credentials.apiPass);
      const response = await axios.get(`${baseUrl}/external/v1/ad-users-or-groups/held-users-or-groups`, auth);

      if (response.data && response.data.length > 0) {
        console.log(chalk.green(`\n✅ Found ${response.data.length} held user(s):`));
        response.data.forEach((user, index) => {
          console.log(chalk.cyan(`\n${index + 1}. User Details:`));
          console.log(JSON.stringify(user, null, 2));
        });
      } else {
        console.log(chalk.green('\n✅ No users are currently on forensic hold.'));
      }
    } catch (error) {
      displayError(error, 'List Held Users');
      process.exit(1);
    }
  });

// Interactive Mode Command
program
  .command('interactive')
  .description('Run in interactive mode with menu options')
  .option('-u, --username <username>', 'Horizon API Username')
  .option('-p, --password <password>', 'Horizon API Password')
  .option('-b, --base-url <url>', 'Horizon API Base URL')
  .action(async (options) => {
    try {
      // Get base URL
      const baseUrl = options.baseUrl || await getBaseUrl();
      
      // Get credentials first
      const credentials = await getCredentials(options.username, options.password);
      console.log(chalk.green('✅ Credentials set successfully!'));

      while (true) {
        const { action } = await inquirer.prompt([
          {
            type: 'list',
            name: 'action',
            message: 'What would you like to do?',
            choices: [
              { name: 'Put User on Hold', value: 'hold' },
              { name: 'Archive VM', value: 'archive' },
              { name: 'Release User from Hold', value: 'release' },
              { name: 'List Held Users', value: 'list' },
              { name: 'Help', value: 'help' },
              { name: 'Exit', value: 'exit' }
            ]
          }
        ]);

        if (action === 'exit') {
          console.log(chalk.yellow('👋 Goodbye!'));
          break;
        }

        if (action === 'help') {
          displayComprehensiveHelp();
          continue;
        }

        try {
          switch (action) {
            case 'hold':
              const { userSid } = await inquirer.prompt([
                {
                  type: 'input',
                  name: 'userSid',
                  message: 'Enter User Security Identifier (SID):',
                  validate: input => input.trim() ? true : 'User SID is required'
                }
              ]);

              console.log(chalk.yellow(`\n🔄 Putting user ${userSid} on forensic hold...`));
              const auth = createAuthHeader(credentials.apiUser, credentials.apiPass);
              const holdResponse = await axios.post(`${baseUrl}/external/v1/ad-users-or-groups/action/hold`, {
                securityIdentifiers: [userSid]
              }, auth);
              displayResult(holdResponse.data, 'User Hold');
              break;

            case 'archive':
              const { vmId } = await inquirer.prompt([
                {
                  type: 'input',
                  name: 'vmId',
                  message: 'Enter VM ID:',
                  validate: input => input.trim() ? true : 'VM ID is required'
                }
              ]);

              console.log(chalk.yellow(`\n🔄 Archiving VM ${vmId}...`));
              const archiveResponse = await axios.post(`${baseUrl}/inventory/v1/machines/action/archive`, {
                ids: [vmId]
              }, auth);
              displayResult(archiveResponse.data, 'VM Archive');
              break;

            case 'release':
              const { releaseUserSid } = await inquirer.prompt([
                {
                  type: 'input',
                  name: 'releaseUserSid',
                  message: 'Enter User Security Identifier (SID):',
                  validate: input => input.trim() ? true : 'User SID is required'
                }
              ]);

              console.log(chalk.yellow(`\n🔄 Releasing user ${releaseUserSid} from forensic hold...`));
              const releaseResponse = await axios.post(`${baseUrl}/external/v1/ad-users-or-groups/action/release-hold`, {
                securityIdentifiers: [releaseUserSid]
              }, auth);
              displayResult(releaseResponse.data, 'User Release');
              break;

            case 'list':
              console.log(chalk.yellow('\n🔄 Fetching list of held users...'));
              const listResponse = await axios.get(`${baseUrl}/external/v1/ad-users-or-groups/held-users-or-groups`, auth);
              
              if (listResponse.data && listResponse.data.length > 0) {
                console.log(chalk.green(`\n✅ Found ${listResponse.data.length} held user(s):`));
                listResponse.data.forEach((user, index) => {
                  console.log(chalk.cyan(`\n${index + 1}. User Details:`));
                  console.log(JSON.stringify(user, null, 2));
                });
              } else {
                console.log(chalk.green('\n✅ No users are currently on forensic hold.'));
              }
              break;
          }
        } catch (error) {
          displayError(error, 'Operation');
        }

        console.log(chalk.gray('\n' + '='.repeat(50) + '\n'));
      }
    } catch (error) {
      displayError(error, 'Interactive Mode');
      process.exit(1);
    }
  });

// Help Command
program
  .command('help')
  .description('Show comprehensive help information including port configuration and usage examples')
  .action(() => {
    displayComprehensiveHelp();
  });

// Parse command line arguments
program.parse(); 