# RHVD - Horizon Forensics CLI Tool

A command-line interface tool for VMware Horizon forensics operations, including user hold management and VM archiving.

## Features

- **User Hold Management**: Put Active Directory users on forensic hold and release them
- **VM Archiving**: Archive virtual machines by VM ID
- **User Listing**: List all currently held users
- **Interactive Mode**: User-friendly interactive menu interface
- **Secure Authentication**: Basic authentication with Horizon API credentials
- **Flexible Configuration**: Horizon API base URL can be provided via command line, environment variable, or interactive prompt

## How It Works

### Architecture Overview

The RHVD tool is a command-line interface application that interacts directly with the VMware Horizon API to perform forensics operations.

### Core Components

#### Configuration Management
The tool supports multiple ways to provide the Horizon API base URL:

1. **Command Line Option**: `-b, --base-url <url>`
2. **Environment Variable**: `HORIZON_API_BASE` in `.env` file
3. **Interactive Prompt**: If not provided via other methods

```javascript
async function getBaseUrl() {
  let baseUrl = process.env.HORIZON_API_BASE;
  
  if (!baseUrl) {
    const answer = await inquirer.prompt([
      {
        type: 'input',
        name: 'baseUrl',
        message: 'Enter Horizon API Base URL (e.g., https://horizon-server.com):',
        validate: input => {
          if (!input.trim()) return 'Base URL is required';
          try {
            new URL(input.trim());
            return true;
          } catch {
            return 'Please enter a valid URL (e.g., https://horizon-server.com)';
          }
        }
      }
    ]);
    baseUrl = answer.baseUrl.trim();
  }
  
  return baseUrl;
}
```

#### Authentication System
```javascript
function createAuthHeader(apiUser, apiPass) {
  return {
    headers: {
      Authorization: `Basic ${Buffer.from(`${apiUser}:${apiPass}`).toString('base64')}`,
      'Content-Type': 'application/json',
      Accept: 'application/json'
    }
  };
}
```

The tool uses Basic Authentication with Base64 encoding to authenticate with the Horizon API. Credentials are:
- Prompted interactively if not provided via command line
- Stored only in memory during the session
- Never logged or persisted

#### API Endpoints

The tool interacts with these VMware Horizon API endpoints:

| Operation | Endpoint | Method | Purpose |
|-----------|----------|--------|---------|
| User Hold | `/external/v1/ad-users-or-groups/action/hold` | POST | Put AD user on forensic hold |
| User Release | `/external/v1/ad-users-or-groups/action/release-hold` | POST | Release user from forensic hold |
| VM Archive | `/inventory/v1/machines/action/archive` | POST | Archive virtual machine |
| List Held Users | `/external/v1/ad-users-or-groups/held-users-or-groups` | GET | Retrieve list of held users |

#### Request/Response Format

**User Hold Request:**
```json
{
  "securityIdentifiers": ["S-1-5-21-1234567890-1234567890-1234567890-1234"]
}
```

**VM Archive Request:**
```json
{
  "ids": ["vm-12345"]
}
```

**Response Format:**
```json
{
  "status": "success",
  "message": "Operation completed successfully",
  "data": { ... }
}
```

### CLI Implementation Details

#### Command Structure
The CLI uses the `commander` library to create a structured command interface:

```javascript
program
  .command('hold-user')
  .description('Put an Active Directory user on forensic hold')
  .argument('[userSid]', 'User Security Identifier (SID)')
  .option('-u, --username <username>', 'Horizon API Username')
  .option('-p, --password <password>', 'Horizon API Password')
  .option('-b, --base-url <url>', 'Horizon API Base URL')
  .action(async (userSid, options) => {
    // Command implementation
  });
```

#### Interactive Prompts
Uses `inquirer` library for user-friendly prompts:

```javascript
const answers = await inquirer.prompt([
  {
    type: 'input',
    name: 'userSid',
    message: 'Enter User Security Identifier (SID):',
    validate: input => input.trim() ? true : 'User SID is required'
  }
]);
```

#### Error Handling
Comprehensive error handling with user-friendly messages:

```javascript
function displayError(error, operation) {
  console.log(chalk.red(`\n❌ ${operation} failed!`));
  if (error.response) {
    console.log(chalk.red(`Status: ${error.response.status}`));
    console.log(chalk.red(`Error: ${error.response.data?.error || error.message}`));
  } else {
    console.log(chalk.red(`Error: ${error.message}`));
  }
}
```

### Security Considerations

#### Credential Management
- Credentials stored in memory only, cleared when process ends
- Input validation before API calls
- Secure credential prompting

#### API Security
- Uses HTTPS for all API communications
- Basic authentication with Base64 encoding
- Input sanitization and validation
- Error messages don't expose sensitive information

#### Environment Variables
```bash
HORIZON_API_BASE=https://your-horizon-server.com
```

### Data Flow

#### CLI Operation Flow
1. **Command Parsing**: Parse command line arguments and options
2. **Base URL Resolution**: Get base URL from command line, environment, or prompt
3. **Input Validation**: Validate required parameters
4. **Credential Collection**: Prompt for credentials if not provided
5. **API Request**: Make authenticated request to Horizon API
6. **Response Processing**: Handle success/error responses
7. **Output Display**: Format and display results to user

### Error Handling Strategy

#### Network Errors
- Connection timeout handling
- Retry logic for transient failures
- Clear error messages for network issues

#### API Errors
- HTTP status code interpretation
- Error message extraction from API responses
- User-friendly error descriptions

#### Validation Errors
- Input format validation
- Required field checking
- SID format validation for user operations
- URL format validation for base URL

### Performance Considerations

#### CLI Performance
- Minimal memory footprint
- Fast startup time
- Efficient command parsing
- Async/await for non-blocking operations

### Extensibility

The modular design allows for easy extension:

#### Adding New Commands
1. Add command definition to CLI
2. Implement command action function
3. Update documentation

## Installation

1. Clone or download this repository
2. Navigate to the backend directory:
   ```bash
   cd backend
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. (Optional) Create a `.env` file in the backend directory with your Horizon API configuration:
   ```
   HORIZON_API_BASE=https://your-horizon-server.com
   ```

5. (Optional) Install globally to use from anywhere:
   ```bash
   npm install -g .
   ```

## Usage

### Interactive Mode (Recommended for beginners)

Run the CLI in interactive mode for a guided experience:

```bash
node cli.js interactive
```

Or if installed globally:
```bash
rhvd interactive
```

### Command Line Mode

#### Put User on Hold
```bash
# Interactive prompts for base URL, user SID, and credentials
node cli.js hold-user

# With user SID provided (default port 443)
node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234

# With custom port and credentials
node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234 -b https://horizon-server.com:8443 -u username -p password
```

#### Archive Virtual Machine
```bash
# Interactive prompts for base URL, VM ID, and credentials
node cli.js archive-vm

# With VM ID provided (default port 443)
node cli.js archive-vm vm-12345

# With custom port and credentials
node cli.js archive-vm vm-12345 -b https://horizon-server.com:9443 -u username -p password
```

#### Release User from Hold
```bash
# Interactive prompts for base URL, user SID, and credentials
node cli.js release-hold

# With user SID provided (default port 443)
node cli.js release-hold S-1-5-21-1234567890-1234567890-1234567890-1234

# With custom port and credentials
node cli.js release-hold S-1-5-21-1234567890-1234567890-1234567890-1234 -b https://horizon-server.com:8443 -u username -p password
```

#### List Held Users
```bash
# Interactive prompts for base URL and credentials
node cli.js list-held-users

# With custom port and credentials
node cli.js list-held-users -b https://horizon-server.com:9443 -u username -p password
```

### Command Options

All commands support the following options:
- `-u, --username <username>`: Horizon API Username
- `-p, --password <password>`: Horizon API Password
- `-b, --base-url <url>`: Horizon API Base URL

If credentials or base URL are not provided via command line options, the CLI will prompt for them interactively.

### Help

Get help for any command:
```bash
node cli.js --help
node cli.js help
node cli.js hold-user --help
node cli.js archive-vm --help
node cli.js release-hold --help
node cli.js list-held-users --help
node cli.js interactive --help
```

The `help` command provides comprehensive information including:
- Available commands and their descriptions
- Command options and usage
- Horizon API Base URL configuration and port information
- Usage examples for different scenarios
- Security notes and error handling information

## Examples

### Example 1: Interactive Mode
```bash
$ node cli.js interactive

📋 Horizon API Base URL Guidelines:
• Default HTTPS (port 443): https://horizon-server.com
• Custom HTTPS port: https://horizon-server.com:8443
• HTTP (not recommended): http://horizon-server.com:8080
• Common VMware Horizon ports: 443, 8443, 9443
💡 Tip: Start without a port, add :8443 or :9443 if connection fails

Enter Horizon API Base URL (e.g., https://horizon-server.com or https://horizon-server.com:8443): https://horizon.company.com
Enter Horizon API Username: admin
Enter Horizon API Password: ********
✅ Credentials set successfully!

What would you like to do? (Use arrow keys)
❯ Put User on Hold
  Archive VM
  Release User from Hold
  List Held Users
  Help
  Exit
```

**Note**: The interactive mode includes a "Help" option that displays comprehensive help information including port configuration, usage examples, and troubleshooting tips.

### Example 2: Direct Command with Base URL
```bash
$ node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234 -b https://horizon.company.com
Enter Horizon API Username: admin
Enter Horizon API Password: ********

🔄 Putting user S-1-5-21-1234567890-1234567890-1234567890-1234 on forensic hold...

✅ User Hold completed successfully!
Response:
{
  "status": "success",
  "message": "User placed on forensic hold"
}
```

### Example 3: Using Environment Variable
```bash
# Set environment variable
export HORIZON_API_BASE=https://horizon.company.com

# Run command (no base URL prompt needed)
$ node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234
Enter Horizon API Username: admin
Enter Horizon API Password: ********
```

### Example 4: Using Custom Port
```bash
$ node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234 -b https://horizon.company.com:8443
Enter Horizon API Username: admin
Enter Horizon API Password: ********

🔄 Putting user S-1-5-21-1234567890-1234567890-1234567890-1234 on forensic hold...

✅ User Hold completed successfully!
Response:
{
  "status": "success",
  "message": "User placed on forensic hold"
}
```

### Example 5: Getting Comprehensive Help
```bash
$ node cli.js help

🚀 RHVD - Horizon Forensics CLI Tool
A command-line interface tool for VMware Horizon forensics operations

📋 Available Commands:
  hold-user [userSid]     Put an Active Directory user on forensic hold
  archive-vm [vmId]       Archive a virtual machine by VM ID
  release-hold [userSid]  Release a user from forensic hold
  list-held-users         List all currently held users
  interactive             Run in interactive mode with menu options
  help                    Show this comprehensive help information

🔧 Command Options:
  -u, --username <username>  Horizon API Username
  -p, --password <password>  Horizon API Password
  -b, --base-url <url>       Horizon API Base URL
  -h, --help                 Show command-specific help

🌐 Horizon API Base URL Configuration:
The Horizon API Base URL may require a specific port depending on your VMware Horizon server configuration.

Default HTTPS (Port 443):
  If your Horizon server uses the default HTTPS port, you typically don't need to specify the port:
  https://horizon.company.com

Custom HTTPS Port:
  If your Horizon server uses a custom HTTPS port, you must specify it:
  https://horizon.company.com:8443
  https://horizon.company.com:9443

Common VMware Horizon Ports:
  | Service                    | Default Port | Protocol |
  |----------------------------|--------------|----------|
  | Horizon Connection Server | 443          | HTTPS    |
  | Horizon Connection Server | 8443, 9443   | HTTPS    |
  | Horizon UAG               | 443          | HTTPS    |
  | Horizon UAG (custom)      | 8443, 9443   | HTTPS    |

💡 Port Usage Tips:
  1. Start without a port (e.g., https://horizon.company.com)
  2. If you get connection errors, try adding common ports like :8443 or :9443
  3. Check with your VMware administrator for the correct port configuration
  4. Use HTTPS whenever possible for security

📝 Usage Examples:
Interactive Mode (Recommended for beginners):
  node cli.js interactive

Command Line Mode:
  # Interactive prompts for base URL, user SID, and credentials
  node cli.js hold-user

  # With user SID provided (default port 443)
  node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234

  # With custom port and credentials
  node cli.js hold-user S-1-5-21-1234567890-1234567890-1234567890-1234 -b https://horizon-server.com:8443 -u username -p password

Environment Variables:
  Create a .env file in the backend directory (optional):
  HORIZON_API_BASE=https://your-horizon-server.com

🔒 Security Notes:
  • Credentials are only stored in memory during the session
  • Passwords are hidden when entered interactively
  • Base URL is validated for proper format
  • Consider using environment variables for credentials in production
  • The .env file should not be committed to version control

❌ Error Handling:
  The CLI provides clear error messages for:
  • Missing credentials
  • Invalid API responses
  • Network connectivity issues
  • Invalid user SIDs or VM IDs
  • Invalid base URL format

📚 Getting Help:
  node cli.js --help                    # Show general help
  node cli.js help                      # Show this comprehensive help
  node cli.js hold-user --help          # Show command-specific help
  node cli.js archive-vm --help         # Show command-specific help
  node cli.js release-hold --help       # Show command-specific help
  node cli.js list-held-users --help    # Show command-specific help
  node cli.js interactive --help        # Show command-specific help

For more information, visit the project documentation or contact your VMware administrator.

## Environment Variables

Create a `.env` file in the backend directory (optional):

```
HORIZON_API_BASE=https://your-horizon-server.com
```

## Port Configuration

The Horizon API Base URL may require a specific port depending on your VMware Horizon server configuration:

### **Default HTTPS (Port 443)**
If your Horizon server uses the default HTTPS port, you typically don't need to specify the port:
```bash
https://horizon.company.com
```

### **Custom HTTPS Port**
If your Horizon server uses a custom HTTPS port, you must specify it:
```bash
https://horizon.company.com:8443
https://horizon.company.com:9443
```

### **Common VMware Horizon Ports**
| Service | Default Port | Protocol |
|---------|-------------|----------|
| Horizon Connection Server | 443 | HTTPS |
| Horizon Connection Server (custom) | 8443, 9443 | HTTPS |
| Horizon UAG (Unified Access Gateway) | 443 | HTTPS |
| Horizon UAG (custom) | 8443, 9443 | HTTPS |

### **Port Usage Tips**
1. **Start without a port** (e.g., `https://horizon.company.com`)
2. **If you get connection errors**, try adding common ports like `:8443` or `:9443`
3. **Check with your VMware administrator** for the correct port configuration
4. **Use HTTPS** whenever possible for security

The CLI will display helpful port guidance when prompting for the base URL.

## Security Notes

- Credentials are only stored in memory during the session
- Passwords are hidden when entered interactively
- Base URL is validated for proper format
- Consider using environment variables for credentials in production environments
- The `.env` file should not be committed to version control

## Error Handling

The CLI provides clear error messages for:
- Missing credentials
- Invalid API responses
- Network connectivity issues
- Invalid user SIDs or VM IDs
- Invalid base URL format

## Development

To run the CLI:
```bash
npm start
```

## Dependencies

- `commander`: CLI framework
- `chalk`: Terminal color output
- `inquirer`: Interactive prompts
- `axios`: HTTP client
- `dotenv`: Environment variable management

## License

ISC 