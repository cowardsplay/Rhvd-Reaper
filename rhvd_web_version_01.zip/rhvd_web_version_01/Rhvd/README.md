# Horizon Forensics Dashboard

A web-based dashboard for managing forensic operations in VMware Horizon environments. This application provides a user-friendly interface for putting Active Directory users on forensic hold, archiving virtual machines, and managing forensic operations.

## Features

- **User Hold Management**: Put Active Directory users on forensic hold using their Security Identifier (SID)
- **VM Archive**: Archive virtual machines by their VM ID
- **User Release**: Release users from forensic hold
- **Held Users List**: View all currently held users
- **Secure Authentication**: Service account-based authentication for API operations

## Project Structure

```
Rhvd/
├── backend/
│   ├── server.js          # Express.js server with API endpoints
│   ├── package.json       # Node.js dependencies
│   └── package-lock.json  # Dependency lock file
├── frontend/
│   └── index.html         # Web dashboard interface
└── README.md              # This file
```

## Prerequisites

- Node.js (v14 or higher)
- npm (comes with Node.js)
- Access to VMware Horizon API
- Service account credentials for Horizon API

## Installation

1. **Clone or download the project**
   ```bash
   cd Rhvd
   ```

2. **Install backend dependencies**
   ```bash
   cd backend
   npm install
   ```

3. **Create environment configuration**
   Create a `.env` file in the `backend` directory with the following variables:
   ```env
   HORIZON_API_BASE=https://your-horizon-server.com
   PORT=3000
   ```

## Configuration

### Environment Variables

Create a `.env` file in the `backend` directory:

```env
# Horizon API base URL (required)
HORIZON_API_BASE=https://your-horizon-server.com

# Server port (optional, defaults to 3000)
PORT=3000
```

### Service Account Setup

You'll need a service account with appropriate permissions in your Horizon environment. The service account should have permissions to:
- Manage Active Directory users and groups
- Archive virtual machines
- Access forensic hold operations

## Usage

1. **Start the server**
   ```bash
   cd backend
   npm start
   ```

2. **Access the dashboard**
   Open your web browser and navigate to `http://localhost:3000`

3. **Set credentials**
   - Enter your service account username and password
   - Click "Set Credentials" to authenticate for the session

4. **Perform operations**
   - **Put User on Hold**: Enter the user's SID and click "Put on Hold"
   - **Archive VM**: Enter the VM ID and click "Archive"
   - **Release User**: Enter the user's SID and click "Release"
   - **List Held Users**: Click "List Held Users" to see all currently held users

## API Endpoints

The backend provides the following REST API endpoints:

- `POST /api/hold-user` - Put a user on forensic hold
- `POST /api/archive-vm` - Archive a virtual machine
- `POST /api/release-hold` - Release a user from forensic hold
- `GET /api/held-users` - List all currently held users

## Security Considerations

- **Credentials**: Service account credentials are stored in session memory only and are not persisted
- **HTTPS**: In production, ensure the application is served over HTTPS
- **Network Security**: Restrict access to the application to authorized users only
- **API Security**: Ensure proper network segmentation and firewall rules for Horizon API access

## Troubleshooting

### Common Issues

1. **"Missing credentials" error**
   - Ensure you've set the service account credentials in the dashboard
   - Verify the credentials are correct

2. **"Missing user SID" error**
   - Ensure you're providing a valid Active Directory Security Identifier
   - SID format: `S-1-5-21-1234567890-1234567890-1234567890-1234`

3. **"Missing VM ID" error**
   - Ensure you're providing a valid VM ID from your Horizon environment

4. **Connection errors**
   - Verify the `HORIZON_API_BASE` URL is correct in your `.env` file
   - Check network connectivity to the Horizon server
   - Ensure the service account has proper permissions

### Logs

Check the console output when running the server for detailed error messages and API responses.

## Development

### Adding New Features

1. **Backend**: Add new endpoints in `backend/server.js`
2. **Frontend**: Add new UI elements and JavaScript functions in `frontend/index.html`

### Dependencies

The project uses the following main dependencies:

- **Express.js**: Web server framework
- **Axios**: HTTP client for API calls
- **CORS**: Cross-origin resource sharing middleware
- **dotenv**: Environment variable management

## License

This project is provided as-is for internal use. Please ensure compliance with your organization's security policies and VMware licensing requirements.

## Support

For issues related to:
- **Horizon API**: Contact your VMware Horizon administrator
- **Application**: Check the troubleshooting section above
- **Network/Infrastructure**: Contact your IT department 